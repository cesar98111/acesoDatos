const WORDS = [
    "Alan",
    "Cesar",
    "Ana",
    "Pedro",
    "Alejandro",
    "Sara",
    "Manuel",
    "Fernando",
    "Maria",
    "Kevin"
]

function random(){
    return  Math.floor(Math.random()*10)
}
function replace(index,replacement, palabra){
    return palabra.substring(0, index) + replacement + palabra.substring(index + 1)
}
function intentos (palabra){
    let aux =""
    for(let j = 1; j<= palabra.length ; j++){
        if(!aux.includes(palabra.substring(j-1,j))){
            aux += palabra.substring(j-1,j)
            aux = aux.toLowerCase()
        
    }
}
    return aux.length
}
const loadWord =()=>{
    const promise = new Promise((resolve, reject)=>{
        const palabra = WORDS[random()]
        if(palabra) resolve(palabra)
        else reject("no se ha encontrado ninguna palabra")
        
    })
    return promise;
}
const isPlaying = ()=>{
   
    const promise = new Promise ((resolve,reject)=>{
        let confirmed = confirm("¿Quieres seguir jugando?")
        if(confirmed) resolve(confirmed)
        else reject ("fin del juego")
    })
    return promise
}
const play = (palabra) =>{
    const palabras = {
        palabra: palabra,
        adivina: "",
        puntuacion: 1,
    }
    
    let letra 
    let i = 0
    
    
        for(let i=0 ;i < palabra.length ; i++){
            palabras.adivina += "X"
        }
        const promise = new Promise((resolve,reject)=>{
            
            
            while(i < intentos(palabra)){
                
                letra = prompt(`adivina la ${palabras.puntuacion}º palabra de 
                        ${palabras.adivina}`)
                
                if(letra === null){

                    i = intentos(palabra)
                    reject("has cancelado el juego...")
                    
                }
                if(!isNaN(letra)){
                    i = intentos(palabra)
                    reject(`Error el valor introducido no es una letra
                    Debe empezar de nuevo..`)
                }       
                for(let j =1;j<=palabras.palabra.length; j++){
                    
                    if(letra.toLowerCase()===palabras.palabra.substring(j-1,j).toLowerCase()){
                            
                            palabras.adivina = replace(j-1,palabras.palabra.substring(j-1,j),palabras.adivina)
                            palabras.puntuacion++
                    }
                    
                }
                i++
                
            }
            if(i>=intentos(palabra)){
                resolve(palabras)
                
            }
        })
            
            return promise

}

const app = () =>{
        
            loadWord()
                .then((palabra)=>{
                    
                    return play(palabra)

                })
                .then((palabras)=>{
                    window.alert(`la palabra es ${palabras.palabra}
                    tu intento ${palabras.adivina}
                    puntuacion ${palabras.puntuacion-1}`)
                    return isPlaying()
                })
                .then(()=>{
                    app()
                })
                .catch((msg)=>{
                    alert(msg);
                })  
        
        }
app()

    
