

const multiplicacion =(operaciones)=>{
    operaciones.resul=1
    if((operaciones.operandos.length >= 2)){
        operaciones.operandos.forEach(value => {
        
            operaciones.resul *= value
        });
        console.log(operaciones)
        
    }else{
        console.log("ERROR: el numero de operandos debe ser mayor que 1")
    }
    
    
}
const division =(operaciones)=>{
    if(operaciones.operandos.length < 2){
        console.log("ERROR: el numero de operandos debe ser 2")
    }else{
        let first = operaciones.operandos[0]
        for(let i = 1; i<operaciones.operandos.length;i++){
            operaciones.resul=first / operaciones.operandos[i]

            first = operaciones.resul
            
        }
        console.log(operaciones)
        
    }
    
}
const potencia =(operaciones)=>{
    if(operaciones.operandos.length !== 2){
        console.log("ERROR: el numero de operandos debe ser 2")
    }else{
        operaciones.resul=Math.pow(operaciones.operandos[0],operaciones.operandos[1])
        console.log(operaciones)
    }
}
const raiz =(operaciones)=>{
    if(operaciones.operandos.length !==1){
        console.log("ERROR: el numero de operandos debe ser 1")
    }else{
        operaciones.resul=Math.sqrt(operaciones.operandos[0])
        console.log(operaciones)
    }
}
const operation =(operaciones)=>{
    switch(operaciones.operacion){
        case "*":
            
            multiplicacion(operaciones)
        break;
        case "/":
            division(operaciones)
        break;
        case "^":
            potencia(operaciones)
        break;
        case "@":
            raiz(operaciones)
        break;
        default:
            console.log("operador invalido")
    }
   
}

const comprobar =(ars)=>{
    const operaciones={
        operacion:"-",
        operandos:[],
        resul:0
    }
    
    let error = false
    if(ars[0].slice(0,12)!=="--operation="){
        error = true
    }else{
        operaciones.operacion=ars[0].slice(12,13)
    }

    for(let i=1; i<args.length;i++){
        
        if((ars[i].slice(0,5)==="--op=")||(!isNaN(ars[i]))){
            let operador = ars[i].slice(5)
            
            if((!isNaN(operador))&&(ars[i]!=="--op=")){
                if(operador!==""){
                    
                    operaciones.operandos[i-1]=parseInt(operador)
                }
                
                
            }else if((!isNaN(operador))&&(!isNaN(ars[i+1]))){
                
                operador=ars[i+1]
                
                operaciones.operandos[i-1]=parseInt(operador)
                
            }
             
        }else{
            
            error = true
        }
        
    }
        operaciones.operandos=operaciones.operandos.filter((numero)=>{
            return numero>0
        })
        
    if(!error){
        operation(operaciones)
    }else{
        console.log("operaciones no validas")
    }
    
    }


const args = process.argv.slice(2)


if(args.length<2){
    console.log("parametros incorrectos")
}else{
    comprobar(args)
}
